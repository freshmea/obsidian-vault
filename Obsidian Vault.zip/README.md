# obsidian-vault

- - - 
- 프라이빗으로 바꾸고 커밋을 해 본다.
- - -
- 자동으로 커밋과 푸쉬가 되게 해 놓았다. 과연 잘 안된다. ㅋ 
- 단축키를 등록해 놓았다. 
	- commit all changes: Ctrl+Alt+s 
	- push : Ctrol+Alt+p