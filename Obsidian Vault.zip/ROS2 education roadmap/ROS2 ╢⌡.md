---
sticker: emoji//1f642
---
ROS2 란 robot operating system 의 약자로 로봇을 다루기 위해서 만들어진 미들웨어 이다. 

