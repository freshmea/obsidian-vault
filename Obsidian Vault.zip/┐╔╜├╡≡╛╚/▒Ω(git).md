# What?
- 2005년 리누스 토르발스에 의해 개발
- 분산 버전관리 시스템(Distributed Version Control Systems - DVCS)
- 로컬에서 개발 진행 가능
- 중앙저장소와 로컬을 따로 관리 


# Link
- 

# Internet Reference
- https://yanacoding.tistory.com/4
- 